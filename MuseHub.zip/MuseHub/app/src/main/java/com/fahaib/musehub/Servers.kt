package com.fahaib.musehub

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ServersScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val servers by VpnManager.servers.collectAsState()
    val results by VpnManager.results.collectAsState()
    val selected by VpnManager.selected.collectAsState()
    val testing by VpnManager.testing.collectAsState()
    val external by VpnManager.externalMode.collectAsState()
    val log by VpnManager.log.collectAsState()

    var showAdd by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Server?>(null) }

    BackHandler(onBack = onBack)

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Ink)
            }
            Text("VPN Servers", Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
            TextButton(enabled = !testing && !external, onClick = { VpnManager.testAll(ctx) }) {
                Text(if (testing) "Test ho raha hai..." else "Sab test karo")
            }
        }

        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(8.dp)) {
                        Text("VPN ka tareeqa", Modifier.padding(8.dp), fontWeight = FontWeight.SemiBold, color = Ink)
                        Row(
                            Modifier.fillMaxWidth().clickable { VpnManager.setExternal(ctx, true) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = external, onClick = { VpnManager.setExternal(ctx, true) })
                            Column {
                                Text("Proton VPN app (split tunneling)", color = Ink)
                                Text("Proton app mein sirf Muse Hub chuno", fontSize = 12.sp, color = Muted)
                            }
                        }
                        Row(
                            Modifier.fillMaxWidth().clickable { VpnManager.setExternal(ctx, false) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = !external, onClick = { VpnManager.setExternal(ctx, false) })
                            Column {
                                Text("App ka apna VPN (WireGuard)", color = Ink)
                                Text("Neeche wale free servers use hote hain", fontSize = 12.sp, color = Muted)
                            }
                        }
                        if (external) {
                            var pkg by remember { mutableStateOf(ProtonControl.packageName(ctx)) }
                            OutlinedTextField(
                                value = pkg,
                                onValueChange = { pkg = it; ProtonControl.setPackage(ctx, it.trim()) },
                                label = { Text("Proton app ka package naam") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().padding(8.dp)
                            )
                        }
                    }
                }
            }
            if (!external) {
            item {
                ServerRow(
                    title = "Auto (sabse tez)",
                    sub = "Khud sabse behtar server chunta hai",
                    ms = null,
                    failed = false,
                    selected = selected == VpnManager.AUTO,
                    onClick = { VpnManager.select(ctx, VpnManager.AUTO) },
                    onDelete = null
                )
            }
            items(servers, key = { it.id }) { s ->
                val r = results[s.id]
                ServerRow(
                    title = s.name,
                    sub = when {
                        r == null -> "Abhi test nahi hua"
                        r.ms != null -> "Chal raha hai"
                        else -> r.note
                    },
                    ms = r?.ms,
                    failed = r != null && r.ms == null,
                    selected = selected == s.id,
                    onClick = { VpnManager.select(ctx, s.id) },
                    onDelete = if (s.custom) ({ deleting = s }) else null
                )
            }
            }
        }

        Box(Modifier.fillMaxWidth().height(110.dp).background(Ink).padding(8.dp)) {
            Column(Modifier.verticalScroll(rememberScrollState(), reverseScrolling = true)) {
                if (log.isEmpty()) {
                    Text("Log yahan aayega", color = Color(0xFFCFCBFF), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
                log.forEach {
                    Text(it, color = Color(0xFFCFCBFF), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Button(
            onClick = { showAdd = true },
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) { Text("+ Server add karo (config paste)") }
    }

    if (showAdd) {
        var text by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Naya server") },
            text = {
                Column {
                    Text("Proton ki WireGuard config ka poora text paste karo.", fontSize = 13.sp, color = Muted)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it; err = null },
                        minLines = 6,
                        maxLines = 10,
                        modifier = Modifier.fillMaxWidth()
                    )
                    err?.let { Text(it, color = Red, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                TextButton(enabled = text.isNotBlank(), onClick = {
                    val e = VpnManager.addServer(ctx, text)
                    if (e == null) showAdd = false else err = e
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
        )
    }

    deleting?.let { s ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("\"${s.name}\" delete karein?") },
            confirmButton = {
                TextButton(onClick = {
                    VpnManager.removeServer(ctx, s.id)
                    deleting = null
                }) { Text("Delete", color = Red) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ServerRow(
    title: String,
    sub: String,
    ms: Int?,
    failed: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    onDelete: (() -> Unit)?
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(1.dp),
        modifier = Modifier.fillMaxWidth().clickable { onClick() }
    ) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = onClick)
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    sub, fontSize = 12.sp,
                    color = if (failed) Red else Muted,
                    maxLines = 3, overflow = TextOverflow.Ellipsis
                )
            }
            if (ms != null) {
                Text(
                    "$ms ms", fontWeight = FontWeight.Bold,
                    color = if (ms < 400) Green else if (ms < 900) Amber else Red
                )
                Spacer(Modifier.width(8.dp))
            }
            if (onDelete != null) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Red)
                }
            }
        }
    }
}
