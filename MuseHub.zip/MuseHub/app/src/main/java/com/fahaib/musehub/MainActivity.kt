package com.fahaib.musehub

import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                VpnManager.connect(applicationContext)
            } else {
                VpnManager.setError("VPN permission nahi di gayi")
            }
        }

    private val filePicker =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            fileCallback?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            )
            fileCallback = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        VpnManager.init(applicationContext)
        startVpn()
        if (savedInstanceState == null) VpnManager.autoConnectIfNeeded(applicationContext)
        val store = AccountStore(applicationContext)
        setContent {
            MuseHubTheme {
                App(
                    store = store,
                    onRetryVpn = { startVpn() },
                    onExit = { finishAndRemoveTask() },
                    onPickFile = { callback, intent ->
                        fileCallback?.onReceiveValue(null)
                        fileCallback = callback
                        try {
                            filePicker.launch(intent)
                        } catch (e: Exception) {
                            fileCallback = null
                            callback.onReceiveValue(null)
                        }
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (ProtonControl.closeWhenBack) {
            ProtonControl.closeWhenBack = false
            finishAndRemoveTask()
        }
    }

    private fun startVpn() {
        if (VpnManager.externalMode.value) {
            VpnManager.connect(applicationContext)
            return
        }
        val intent: Intent? = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else VpnManager.connect(applicationContext)
    }

    override fun onDestroy() {
        super.onDestroy()
        // App fully closed (not just rotated) -> turn the VPN off.
        if (isFinishing) VpnManager.disconnect(applicationContext)
    }
}
