package com.fahaib.musehub

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings

/** Shared state between the app UI and the accessibility service that presses Proton's buttons. */
object ProtonControl {
    enum class Action { CONNECT, DISCONNECT }

    const val DEFAULT_PKG = "ch.protonvpn.android"

    @Volatile var pending: Action? = null
    @Volatile var pendingSince = 0L
    @Volatile var clicked = false
    @Volatile var closeAfter = false
    @Volatile var closeWhenBack = false
    @Volatile var followUp: Action? = null

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("vpn", Context.MODE_PRIVATE)

    fun packageName(ctx: Context): String =
        prefs(ctx).getString("protonPkg", null)?.takeIf { it.isNotBlank() } ?: DEFAULT_PKG

    fun setPackage(ctx: Context, pkg: String) {
        prefs(ctx).edit().putString("protonPkg", pkg).apply()
    }

    fun isServiceEnabled(ctx: Context): Boolean {
        val enabled = Settings.Secure.getString(
            ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains(ctx.packageName + "/")
    }

    /** Opens the Proton app and asks the service to press Connect / Disconnect. */
    fun run(ctx: Context, action: Action, closeAfterDone: Boolean = false): Boolean {
        val app = ctx.applicationContext
        val intent = app.packageManager.getLaunchIntentForPackage(packageName(app)) ?: return false
        pending = action
        pendingSince = System.currentTimeMillis()
        clicked = false
        closeAfter = closeAfterDone
        closeWhenBack = false
        followUp = null
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        Handler(Looper.getMainLooper()).post {
            try {
                app.startActivity(intent)
            } catch (_: Exception) {
                pending = null
            }
        }
        return true
    }

    /** Disconnect, then connect again (Proton picks another server from its default connection). */
    fun reconnect(ctx: Context): Boolean {
        if (!run(ctx, Action.DISCONNECT)) return false
        followUp = Action.CONNECT
        return true
    }
}
