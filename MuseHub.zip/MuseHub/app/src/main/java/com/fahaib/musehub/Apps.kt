package com.fahaib.musehub

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.graphics.drawable.Drawable
import android.os.Process
import android.os.UserManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

data class AppEntry(
    val label: String,
    val pkg: String,
    val cls: String,
    val userSerial: Long,
    val clone: Boolean,
    val icon: Drawable?
)

object Apps {
    /** All launchable apps in this profile and in other profiles of the same group (clone / dual apps). */
    fun list(ctx: Context): List<AppEntry> {
        val la = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        val um = ctx.getSystemService(Context.USER_SERVICE) as UserManager
        val me = Process.myUserHandle()
        val out = mutableListOf<AppEntry>()
        for (u in la.profiles) {
            val serial = um.getSerialNumberForUser(u)
            for (ai in la.getActivityList(null, u)) {
                val pkg = ai.applicationInfo.packageName
                if (pkg == ctx.packageName) continue
                val icon = try { ai.getIcon(0) } catch (_: Exception) { null }
                out += AppEntry(ai.label.toString(), pkg, ai.componentName.className, serial, u != me, icon)
            }
        }
        return out.sortedWith(
            compareBy<AppEntry>(
                { if (it.label.contains("muse", true) || it.pkg.contains("muse", true)) 0 else 1 },
                { it.label.lowercase() }
            )
        )
    }

    /** Opens the chosen app instance. Returns false if it could not be opened. */
    fun launch(ctx: Context, app: AppRef): Boolean {
        val la = ctx.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        val um = ctx.getSystemService(Context.USER_SERVICE) as UserManager
        val mySerial = um.getSerialNumberForUser(Process.myUserHandle())
        val user = try { um.getUserForSerialNumber(app.user) } catch (_: Exception) { null }
        if (user != null) {
            return try {
                la.startMainActivity(ComponentName(app.pkg, app.cls), user, null, null)
                true
            } catch (_: Exception) {
                false
            }
        }
        // Never fall back to the original app when a clone was chosen (it would be the wrong account).
        if (app.user != mySerial) return false
        val i = ctx.packageManager.getLaunchIntentForPackage(app.pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            true
        } catch (_: Exception) {
            false
        }
    }
}

@Composable
fun AppPickerDialog(onPick: (AppRef) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val all = remember { try { Apps.list(ctx) } catch (_: Exception) { emptyList() } }
    var q by remember { mutableStateOf("") }
    val shown = remember(q, all) {
        if (q.isBlank()) all else all.filter { it.label.contains(q, true) || it.pkg.contains(q, true) }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("App chuno") },
        text = {
            Column {
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it },
                    label = { Text("Search (jaise Muse)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                if (all.isEmpty()) {
                    Text("Apps ki list nahi mili.", color = Red, fontSize = 12.sp)
                }
                LazyColumn(Modifier.height(360.dp)) {
                    items(shown, key = { "${it.pkg}/${it.userSerial}/${it.cls}" }) { e ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable {
                                    onPick(AppRef(e.pkg, e.cls, e.userSerial, e.label + if (e.clone) " (clone)" else ""))
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val bmp = remember(e) {
                                try { e.icon?.toBitmap(96, 96)?.asImageBitmap() } catch (_: Exception) { null }
                            }
                            if (bmp != null) {
                                Image(bitmap = bmp, contentDescription = null, modifier = Modifier.size(36.dp))
                            } else {
                                Spacer(Modifier.size(36.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(e.label, color = Ink)
                                Text(
                                    e.pkg + if (e.clone) "  - clone/profile #${e.userSerial}" else "",
                                    fontSize = 11.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
