package com.fahaib.musehub

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Only does something while Muse Hub has asked for a Connect / Disconnect
 * (ProtonControl.pending) and only looks at the Proton VPN app's window.
 */
class ProtonService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastClick = 0L
    private var lastHome = 0L

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val action = ProtonControl.pending ?: return
        val pkg = ProtonControl.packageName(this)
        if (event?.packageName?.toString() != pkg) return
        val now = System.currentTimeMillis()
        if (now - ProtonControl.pendingSince > 45_000) {
            ProtonControl.pending = null
            return
        }
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return

        val want = if (action == ProtonControl.Action.CONNECT) "Connect" else "Disconnect"
        val done = if (action == ProtonControl.Action.CONNECT) "Disconnect" else "Connect"

        if (ProtonControl.clicked) {
            if (find(root, done) != null) finishUp()
            return
        }
        val target = find(root, want)
        if (target != null) {
            if (now - lastClick < 1500) return
            lastClick = now
            if (click(target)) ProtonControl.clicked = true
            return
        }
        if (find(root, done) != null) {
            finishUp() // already in the wanted state
            return
        }
        // Not on Proton's home screen: tap its Home tab.
        val home = find(root, "Home")
        if (home != null && now - lastHome > 1500) {
            lastHome = now
            click(home)
        }
    }

    private fun find(root: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? =
        root.findAccessibilityNodeInfosByText(label)?.firstOrNull {
            it.text?.toString()?.trim() == label || it.contentDescription?.toString()?.trim() == label
        }

    private fun click(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
            depth++
        }
        return false
    }

    private fun finishUp() {
        if (ProtonControl.pending == null) return
        val next = ProtonControl.followUp
        if (next != null) {
            ProtonControl.followUp = null
            ProtonControl.pending = next
            ProtonControl.pendingSince = System.currentTimeMillis()
            ProtonControl.clicked = false
            return
        }
        ProtonControl.closeWhenBack = ProtonControl.closeAfter
        ProtonControl.pending = null
        ProtonControl.clicked = false
        ProtonControl.closeAfter = false
        goBack(0)
    }

    /** Presses Back until Proton is gone and Muse Hub is in front again (max 3 times). */
    private fun goBack(tries: Int) {
        handler.postDelayed({
            performGlobalAction(GLOBAL_ACTION_BACK)
            if (tries < 2) {
                handler.postDelayed({
                    val r = rootInActiveWindow
                    if (r?.packageName?.toString() == ProtonControl.packageName(this)) goBack(tries + 1)
                }, 1000)
            }
        }, if (tries == 0) 1500L else 0L)
    }
}
