package com.fahaib.musehub

import android.content.Intent
import android.net.Uri
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

internal val Brand = Color(0xFF5B4BDB)
internal val BrandSoft = Color(0xFFEAE7FF)
internal val Bg = Color(0xFFF6F5FF)
internal val Ink = Color(0xFF1E1B3A)
internal val Muted = Color(0xFF6E6A8A)
internal val Green = Color(0xFF1FA971)
internal val Amber = Color(0xFFE59A00)
internal val Red = Color(0xFFD64545)

@Composable
fun MuseHubTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Brand,
            onPrimary = Color.White,
            background = Bg,
            surface = Color.White,
            onSurface = Ink
        ),
        content = content
    )
}

@Composable
fun App(
    store: AccountStore,
    onRetryVpn: () -> Unit,
    onPickFile: (ValueCallback<Array<Uri>>, Intent) -> Unit
) {
    var accounts by remember { mutableStateOf(store.load()) }
    var open by remember { mutableStateOf<Account?>(null) }
    var showServers by remember { mutableStateOf(false) }
    val status by VpnManager.status.collectAsState()
    val message by VpnManager.message.collectAsState()

    fun update(list: List<Account>) {
        accounts = list
        store.save(list)
    }

    val current = open
    if (current != null) {
        WebScreen(
            account = current,
            status = status,
            onBack = { open = null },
            onRetryVpn = onRetryVpn,
            onPickFile = onPickFile
        )
    } else if (showServers) {
        ServersScreen(onBack = { showServers = false })
    } else {
        HomeScreen(
            onServers = { showServers = true },
            accounts = accounts,
            status = status,
            message = message,
            onRetryVpn = onRetryVpn,
            onOpen = { open = it },
            onAdd = { name, url -> update(accounts + AccountStore.newAccount(name, url)) },
            onEdit = { acc, name, url ->
                update(accounts.map {
                    if (it.id == acc.id) it.copy(name = name, url = AccountStore.normalizeUrl(url)) else it
                })
            },
            onDelete = { acc ->
                try {
                    ProfileStore.getInstance().deleteProfile(acc.profile)
                } catch (_: Exception) {
                }
                update(accounts.filter { it.id != acc.id })
            }
        )
    }
}

@Composable
fun HomeScreen(
    onServers: () -> Unit,
    accounts: List<Account>,
    status: VpnStatus,
    message: String?,
    onRetryVpn: () -> Unit,
    onOpen: (Account) -> Unit,
    onAdd: (String, String) -> Unit,
    onEdit: (Account, String, String) -> Unit,
    onDelete: (Account) -> Unit
) {
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Account?>(null) }
    var deleting by remember { mutableStateOf<Account?>(null) }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(24.dp))
            Text("Muse Hub", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("Aap ke saare Muse AI accounts, ek jagah", fontSize = 14.sp, color = Muted)
            Spacer(Modifier.height(18.dp))

            VpnCard(status, message, onRetryVpn, onServers)

            Spacer(Modifier.height(22.dp))
            Text("Accounts", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Spacer(Modifier.height(10.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 100.dp)
            ) {
                items(accounts, key = { it.id }) { acc ->
                    AccountCard(
                        account = acc,
                        onClick = { onOpen(acc) },
                        onEdit = { editing = acc },
                        onDelete = { deleting = acc }
                    )
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { showAdd = true },
            containerColor = Brand,
            contentColor = Color.White,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Account add karo")
        }
    }

    if (showAdd) {
        AccountDialog(
            title = "Naya account",
            initialName = "Account ${accounts.size + 1}",
            initialUrl = DEFAULT_URL,
            onDismiss = { showAdd = false },
            onConfirm = { n, u ->
                onAdd(n, u)
                showAdd = false
            }
        )
    }
    editing?.let { acc ->
        AccountDialog(
            title = "Account edit karo",
            initialName = acc.name,
            initialUrl = acc.url,
            onDismiss = { editing = null },
            onConfirm = { n, u ->
                onEdit(acc, n, u)
                editing = null
            }
        )
    }
    deleting?.let { acc ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("\"${acc.name}\" delete karein?") },
            text = { Text("Is account ka saved login bhi hat jayega.") },
            confirmButton = {
                TextButton(onClick = {
                    onDelete(acc)
                    deleting = null
                }) { Text("Delete", color = Red) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun VpnCard(status: VpnStatus, message: String?, onRetry: () -> Unit, onServers: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val activeName by VpnManager.activeName.collectAsState()
    val activeMs by VpnManager.activeMs.collectAsState()
    val (color, title, sub) = when (status) {
        VpnStatus.CONNECTED -> Triple(Green, "VPN connected", "USA - ${activeName ?: ""}" + (activeMs?.let { " - $it ms" } ?: ""))
        VpnStatus.CONNECTING -> Triple(Amber, "Connect ho raha hai...", message ?: "Thora intezar karein")
        VpnStatus.ERROR -> Triple(Red, "VPN connect nahi hua", message ?: "Dobara try karein")
        VpnStatus.DISCONNECTED -> Triple(Red, "VPN band hai", "Accounts kholne ke liye VPN zaroori hai")
    }
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(14.dp).clip(CircleShape).background(color))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.SemiBold, color = Ink)
                    Text(sub, fontSize = 12.sp, color = Muted, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
                if (status == VpnStatus.CONNECTING) {
                    TextButton(onClick = { VpnManager.cancel(ctx) }) { Text("Cancel") }
                } else if (status == VpnStatus.ERROR || status == VpnStatus.DISCONNECTED) {
                    TextButton(onClick = onRetry) { Text("Retry") }
                }
            }
            TextButton(onClick = onServers, modifier = Modifier.padding(start = 8.dp)) {
                Text("Servers (list, test, add)")
            }
        }
    }
}

@Composable
fun AccountCard(account: Account, onClick: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth().clickable { onClick() }
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(CircleShape).background(BrandSoft),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    account.name.trim().take(1).uppercase().ifEmpty { "M" },
                    color = Brand, fontWeight = FontWeight.Bold, fontSize = 20.sp
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(account.name, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(account.url.removePrefix("https://").removePrefix("http://"), fontSize = 12.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Menu", tint = Muted)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Rename / edit") },
                        leadingIcon = { Icon(Icons.Filled.Edit, null) },
                        onClick = { menu = false; onEdit() }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = Red) },
                        leadingIcon = { Icon(Icons.Filled.Delete, null, tint = Red) },
                        onClick = { menu = false; onDelete() }
                    )
                }
            }
        }
    }
}

@Composable
fun AccountDialog(
    title: String,
    initialName: String,
    initialUrl: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String) -> Unit
) {
    var name by remember { mutableStateOf(initialName) }
    var url by remember { mutableStateOf(initialUrl) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("Naam") }, singleLine = true)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(url, { url = it }, label = { Text("Website address") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = { onConfirm(name.trim(), url) }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun WebScreen(
    account: Account,
    status: VpnStatus,
    onBack: () -> Unit,
    onRetryVpn: () -> Unit,
    onPickFile: (ValueCallback<Array<Uri>>, Intent) -> Unit
) {
    var webView by remember { mutableStateOf<WebView?>(null) }
    var progress by remember { mutableIntStateOf(0) }
    var errorText by remember { mutableStateOf<String?>(null) }
    val multiProfile = remember { WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE) }

    BackHandler {
        val w = webView
        if (w != null && w.canGoBack()) w.goBack() else onBack()
    }

    Column(Modifier.fillMaxSize().background(Color.White)) {
        Row(
            Modifier.fillMaxWidth().background(Bg).padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Ink)
            }
            Text(account.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (status == VpnStatus.CONNECTED) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(Green))
                IconButton(onClick = { webView?.reload() }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Reload", tint = Ink)
                }
            }
        }
        if (status == VpnStatus.CONNECTED && progress in 1..99) {
            LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Brand)
        }
        errorText?.let {
            Text("Error: $it", color = Red, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
        }
        if (!multiProfile) {
            Text(
                "Is phone ke WebView mein alag sessions supported nahi. Android System WebView / Chrome update karein.",
                color = Red, fontSize = 12.sp, modifier = Modifier.padding(8.dp)
            )
        }

        if (status == VpnStatus.CONNECTED) {
            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        if (multiProfile) {
                            ProfileStore.getInstance().getOrCreateProfile(account.profile)
                            WebViewCompat.setProfile(this, account.profile)
                        }
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.userAgentString = settings.userAgentString.replace("; wv", "")
                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                errorText = null
                            }

                            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                                if (request.isForMainFrame) errorText = "${error.errorCode} ${error.description}"
                            }
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                progress = newProgress
                            }

                            override fun onShowFileChooser(
                                webView: WebView?,
                                filePathCallback: ValueCallback<Array<Uri>>,
                                fileChooserParams: WebChromeClient.FileChooserParams
                            ): Boolean {
                                onPickFile(filePathCallback, fileChooserParams.createIntent())
                                return true
                            }
                        }
                        loadUrl(account.url)
                        webView = this
                    }
                },
                onRelease = {
                    it.destroy()
                    webView = null
                }
            )
        } else {
            // Kill-switch: never show the account while the VPN is down.
            Column(
                Modifier.weight(1f).fillMaxWidth().background(Bg).padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    if (status == VpnStatus.CONNECTING) "VPN connect ho raha hai..." else "VPN connected nahi hai",
                    fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Ink, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Aap ki asli IP bachane ke liye account tab khulega jab USA VPN chal raha ho.",
                    color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center
                )
                if (status != VpnStatus.CONNECTING) {
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onRetryVpn) { Text("VPN connect karo") }
                }
            }
        }
    }
}
