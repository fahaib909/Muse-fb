package com.fahaib.musehub

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

// Change this if your Muse AI website address is different.
const val DEFAULT_URL = "https://muse.ai"

data class Account(val id: String, val name: String, val url: String) {
    /** Each account gets its own WebView profile = its own cookies/login/storage. */
    val profile: String get() = "acc_$id"
}

class AccountStore(context: Context) {
    private val prefs = context.getSharedPreferences("accounts", Context.MODE_PRIVATE)

    fun load(): List<Account> {
        val raw = prefs.getString("list", null)
        if (raw == null) {
            val defaults = listOf(newAccount("Account 1", DEFAULT_URL), newAccount("Account 2", DEFAULT_URL))
            save(defaults)
            return defaults
        }
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Account(o.getString("id"), o.getString("name"), o.getString("url"))
        }
    }

    fun save(list: List<Account>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("url", it.url))
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    companion object {
        fun newAccount(name: String, url: String) =
            Account(UUID.randomUUID().toString().replace("-", "").take(12), name, normalizeUrl(url))

        fun normalizeUrl(url: String): String {
            val u = url.trim().ifEmpty { DEFAULT_URL }
            return if (u.startsWith("http://") || u.startsWith("https://")) u else "https://$u"
        }
    }
}
