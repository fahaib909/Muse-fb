package com.fahaib.musehub

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

// Used only for website (web) accounts.
const val DEFAULT_URL = "https://muse.ai/?aymh_complete=1"

/** An installed app (original or clone/profile copy) that an account opens. */
data class AppRef(val pkg: String, val cls: String, val user: Long, val label: String)

data class Account(val id: String, val name: String, val url: String, val app: AppRef? = null) {
    /** Each web account gets its own WebView profile = its own cookies/login/storage. */
    val profile: String get() = "acc_$id"
}

class AccountStore(context: Context) {
    private val prefs = context.getSharedPreferences("accounts", Context.MODE_PRIVATE)

    fun load(): List<Account> {
        val raw = prefs.getString("list", null)
        if (raw == null) {
            val defaults = listOf(newAccount("Account 1", DEFAULT_URL), newAccount("Account 2", DEFAULT_URL))
            save(defaults)
            return defaults
        }
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val app = if (o.has("pkg")) {
                AppRef(o.getString("pkg"), o.getString("cls"), o.optLong("user", -1L), o.optString("label", ""))
            } else null
            Account(o.getString("id"), o.getString("name"), o.getString("url"), app)
        }
    }

    fun save(list: List<Account>) {
        val arr = JSONArray()
        list.forEach {
            val o = JSONObject().put("id", it.id).put("name", it.name).put("url", it.url)
            it.app?.let { a ->
                o.put("pkg", a.pkg).put("cls", a.cls).put("user", a.user).put("label", a.label)
            }
            arr.put(o)
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    companion object {
        fun newAccount(name: String, url: String, app: AppRef? = null) =
            Account(UUID.randomUUID().toString().replace("-", "").take(12), name, normalizeUrl(url), app)

        fun normalizeUrl(url: String): String {
            val u = url.trim().ifEmpty { DEFAULT_URL }
            return if (u.startsWith("http://") || u.startsWith("https://")) u else "https://$u"
        }
    }
}
